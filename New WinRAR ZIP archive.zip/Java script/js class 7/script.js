let date = new Date();
document.getElementById("originalStringBox").innerHTML = date;

let dayNames = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

function inputText(){
    return  document.getElementById("inputText").value
  }

function showOutput(output){
    document.getElementById("output").innerHTML = output
}

function tellTime(){

    let now = new Date();
    let theHr = now.getHours();
    let theMin = now.getMinutes();
    let sec = now.getSeconds();

    output.innerHTML += '<br>You click the button @ ' + theHr + ':' + theMin + ':' + sec + ':'
}

function nameofToday(){
    let rightNow = new Date();
    console.log('"new date"',rightNow)
    let theDay = rightNow.getDay();
    console.log(theDay)
    let nameofToday = dayNames[theDay];
    console.log(nameofToday);

    showOutput(nameofToday)
    tellTime()
}

function calulateDays(){
    let dob = inputText();
    if(!dob){
        Toastify({
            text: "Please enter your date of birth.",
            duration: 3000,
            destination: "https://github.com/apvarun/toastify-js",
            newWindow: true,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "left", // `left`, `center` or `right`
            stopOnFocus: true, // Prevents dismissing of toast on hover
            style: {
              background: "linear-gradient(to right, #93291e, #ed213a)",
            },
            onClick: function(){} // Callback after click
          }).showToast();
          return;
    }
    let toDay = new Date();
    let bornDate = new Date(dob);

    let toDayTime = toDay.getTime()
    let bornDateTime = bornDate.getTime()

    let msDiff = toDayTime - bornDateTime;
    console.log(msDiff)

    let daysDiff = msDiff / (1000 * 60 * 60 * 24);
    let html = Math.floor(daysDiff) + " Days have been passed since you born.";

    showOutput(html)
    tellTime()
}
function nextBirthday(){
    let dob = inputText();
    if(!dob){
        Toastify({
            text: "Please enter your next year date of birth.",
            duration: 3000,
            destination: "https://github.com/apvarun/toastify-js",
            newWindow: true,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "left", // `left`, `center` or `right`
            stopOnFocus: true, // Prevents dismissing of toast on hover
            style: {
              background: "linear-gradient(to right, #93291e, #ed213a)",
            },
            onClick: function(){} // Callback after click
          }).showToast();
          return
    }
    let toDay = new Date();
    let nextBirthday = new Date(dob);

    let msDiff = nextBirthday.getTime() - toDay.getTime();

    let daysDiff = msDiff / (1000 * 60 * 60 *24);
    let html = "Your next birthday is "+ Math.floor(daysDiff)+" days away";

    showOutput(html)
    tellTime()
}

function greetUsers(msg){
    document.getElementById("greetingMessage").innerHTML = msg

}

function greetUser() {
    let userName = prompt("Enter your name");

    let now = new Date();
    let hour = now.getHours();

    let greetingMessage = "Good ";

    if (hour >= 4 && hour < 12) {
        greetingMessage += "Morning"
    } else if (hour >= 12 && hour < 17) {
        greetingMessage += "Afternoon"
    } else if (hour >= 17 && hour < 20) {
        greetingMessage += "Evening"
    } else {
        greetingMessage += "Night"
    }

    let msg = greetingMessage + " " + userName

    greetUsers(msg)
    tellTime()
}

function tellTime1(){
    tellTime()
}
function tellTime2(){
    tellTime()
}
function tellTime3(){
    tellTime()
}

function calculateTax(price , taxRate){
    return price * taxRate / 100;
}

function calculateTaxbtn(){

    let price = prompt('Enter price');
    let taxRate = 18;

    let tax = calculateTax(price , taxRate);

    let html = "Tax: " + tax;

    showOutput(html)

}

function calculateTotal(price){
    let taxRate;
    if (price < 1000){
        taxRate = 8;
    } else {
        taxRate = 18;
    }
    let tax = calculateTax(price, taxRate)

    let total = price + tax;
    console.log(total)

    return total;
}

function controllingLenght(){
    let price = prompt("Enter price");
    price = parseFloat(price);
    if(!price){
        Toastify({
            text: "Please enter price.",
            duration: 3000,
            destination: "https://github.com/apvarun/toastify-js",
            newWindow: true,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "left", // `left`, `center` or `right`
            stopOnFocus: true, // Prevents dismissing of toast on hover
            style: {
              background: "linear-gradient(to right, #93291e, #ed213a)",
            },
            onClick: function(){} // Callback after click
          }).showToast();
          return;
    }
    let total = calculateTotal(price);

    let html = "Total: " + Math.round(total);

    console.log(html)
    showOutput(html)
}
