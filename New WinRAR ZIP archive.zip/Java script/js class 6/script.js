let originalNumber = "<h2>25.12345</h2>"

document.getElementById("originalStringBox").innerHTML = originalNumber

function inputText(){
  return  document.getElementById("inputText").value
}
function roundANumber(){
    let number = inputText();

    if(!number){
        Toastify({
            text: "Please enter a floating point number.",
            duration: 3000,
            destination: "https://github.com/apvarun/toastify-js",
            newWindow: true,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "left", // `left`, `center` or `right`
            stopOnFocus: true, // Prevents dismissing of toast on hover
            style: {
              background: "linear-gradient(to right, #93291e, #ed213a)",
            },
            onClick: function(){} // Callback after click
          }).showToast();
    }
    let roundTheNumber = Math.round(number)

    let html = "<h1 class='text-primarytheme mb-0'>"+roundTheNumber+"</h1>"

    document.getElementById("output").innerHTML = html
}

function ceilANumber(){
    let number = inputText();

    if(!number){
        Toastify({
            text: "Please enter a floating point number.",
            duration: 3000,
            destination: "https://github.com/apvarun/toastify-js",
            newWindow: true,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "left", // `left`, `center` or `right`
            stopOnFocus: true, // Prevents dismissing of toast on hover
            style: {
              background: "linear-gradient(to right, #93291e, #ed213a)",
            },
            onClick: function(){} // Callback after click
          }).showToast();
    }
    let ceilTheNumber = Math.ceil(number)

    let html = "<h1 class='text-primarytheme mb-0'>"+ceilTheNumber+"</h1>"

    document.getElementById("output").innerHTML = html
}

function floorANumber(){
    let number = inputText();

    if(!number){
           Toastify({
            text: "Please enter a floating point number.",
            duration: 3000,
            destination: "https://github.com/apvarun/toastify-js",
            newWindow: true,
            close: true,
            gravity: "bottom", // `top` or `bottom`
            position: "left", // `left`, `center` or `right`
            stopOnFocus: true, // Prevents dismissing of toast on hover
            style: {
              background: "linear-gradient(to right, #93291e, #ed213a)",
            },
            onClick: function(){} // Callback after click
          }).showToast();
    }

    let floorTheNumber = Math.floor(number)

    let html = "<h1 class='text-primarytheme mb-0'>"+floorTheNumber+"</h1>"

    document.getElementById("output").innerHTML = html
}

function generateANumber(){

let randomNumber = Math.random();
console.log(randomNumber)

let html = "<h1 class='text-primarytheme mb-0'>"+randomNumber+"</h1>"

document.getElementById("output").innerHTML = html;
}

// function throwADice(){

//     let randomNumber = Math.random();
//     randomNumber = (randomNumber * 6) + 1;

// let dice = Math.floor(randomNumber);

// let html = "<h1 class='text-primarytheme mb-0'>"+dice+"</h1><span>Generating a random number from 1 to 6</span>"
// document.getElementById("output").innerHTML = html;
// }

function generateAPassword(){
  let length = "16";
  if(!length){
    Toastify({
      text: "Please enter a floating point number.",
      duration: 3000,
      destination: "https://github.com/apvarun/toastify-js",
      newWindow: true,
      close: true,
      gravity: "bottom", // `top` or `bottom`
      position: "left", // `left`, `center` or `right`
      stopOnFocus: true, // Prevents dismissing of toast on hover
      style: {
        background: "linear-gradient(to right, #93291e, #ed213a)",
      },
      onClick: function(){} // Callback after click
    }).showToast();
    return;
  }
  let randomString = ""
  let upperCaseAlphabates = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  let lowerCaseAlphabates = "abcdefghijklmnopqrstuvwxyz"
  let number = "0123456789"
  let symbols = "`~!@#$%^&*-_=+/?.," 

  let possibleString = upperCaseAlphabates + lowerCaseAlphabates + number + symbols;
  // console.log(possibleString.length)

  let limit = length;
  for(let i = 0; i < limit; i++){

    let randomNumber = Math.random();
    randomString += possibleString.charAt(Math.floor(randomNumber * possibleString.length))
  }
  let html = '<h6 class="text-primarytheme mb-0">'+randomString+'</h6><span>Generating random string & the length is: <span style="font-size:15px;color:red;">'+length+'</span></span>'

  document.getElementById("output").innerHTML = html;
}

function convertingStrings(){
  let number = inputText();

  let num = "251.125486";
   num = Number(num)
   console.log(typeof num)

   num = num.toFixed(2)

   num = Number(num)
   console.log(typeof num)
   console.log(num)

   
}
function calculateGST(){
let cost = inputText();

if(!cost){
  alert("Please type something to calculate")
  return;
}
cost  = Number(cost)
let textInput = +prompt("Enter your tax")

let tax = cost * (textInput / 100)

let totalCost = cost + tax;
totalCost = Math.round(totalCost);

document.getElementById("output").innerHTML = 'Your bill = <span class="text-primarytheme mb-0 fw-bold fw-18">'+cost+'</span>'
document.getElementById("output").innerHTML += '<br>Tax '+textInput+'% = <span class="text-danger mb-0 fw-bold fw-18">'+tax.toFixed(2)+'</span>'
document.getElementById("output").innerHTML += '<br>Total amount including tax = <span class="text-success mb-0 fw-bold fw-18">'+totalCost+'</span>'
}

function clearOutputButton(){

  document.getElementById("output").innerHTML = ""

}



// let  num1 = 10.13;
// let num2 = 54.18;
// let num3 = 354.19;

// let totalPrice = num1 + num2 + num3

// let totalExactPrice = Math.round(totalPrice)

// // console.log('totalPrice',totalPrice)
// // console.log('totalExactPrice',totalExactPrice)

// console.log('floor',Math.floor(1.99))

// console.log('ceil',Math.ceil(1.001))
