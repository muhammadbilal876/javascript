let users ={
    firstName: "Bilal",
    lastName: "Hussain",
    City: "Faisalabad"
}
console.log(users['firstName'])