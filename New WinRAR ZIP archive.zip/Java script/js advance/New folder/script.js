// JavaScript String 
const createString = () => {
    let fullName = "Bilal"
    localStorage.setItem("fullName", fullName)
    console.log(fullName)
}
const readString = () => {
    let fullName = localStorage.getItem("fullName")
    document.getElementById("fullName").innerHTML = fullName
    console.log(fullName)
}
const updateString = () => {
    let fullName = "Saqib Ali"
    localStorage.setItem("fullName", fullName)
}
const deleteString = () => {
    localStorage.removeItem("fullName")
}



// JavaScript Array 
const createArray = () => {
    let users = [{ fullName: "Ahmad"},{ fullName: "Hassan"}]

    localStorage.setItem("users", JSON.stringify(users))
}

const readArray = () => {
    const users = JSON.parse(localStorage.getItem("users"))
    console.log('users =>',users)
}

const updateArray = () => {
    let newUser = { fullName: "Ali Raza"}
    const users = JSON.parse(localStorage.getItem("users"))

    users.push(newUser)
    localStorage.setItem('users', JSON.stringify(users))
}

const deleteArray = () => {
    localStorage.removeItem("users")
}

window.onload = () => {
    readString()
}