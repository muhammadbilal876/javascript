// function helle(){
//    return "hello rizwan"
// }
// console.log(helle)
// const sayHello = () => "Hello Rizwan"

// console.log(sayHello())

// ()=>{}


let users = [
    {name: "Bilal", city: "Faisalabad", age: 18, email: "Bilal@gmail.com", status: "active", id: "123"},
    {name: "Ahmad", city: "Faisalabad", age: 20, email: "Ahmad@gmail.com", status: "inactive", id: "124"},
    {name: "Ali", city: "Faisalabad", age: 17, email: "Ali@gmail.com", status: "active", id: "125"},
    {name: "Hassan", city: "Faisalabad", age: 7, email: "Hassan@gmail.com", status: "active", id: "126"},
    {name: "Abdullah", city: "Faisalabad", age: 25, email: "Abdullah@gmail.com", status: "inactive", id: "127"}
]

const mapMethod = () => {
   let newUsers = users.map((user, index) => {
    // return user.name + " Pak"
    return user.age * 2
    })

console.log(newUsers)
}

const filterMethod = ()  => {
    let filteredUser = users.filter((user, index)=> {
        return user.age >= 18
    })
    console.log(filteredUser)
}

const findMethod = () => {
    let document = users.find((user, index)=>{
        return user.age >= 20
    })
    console.log(document)
}