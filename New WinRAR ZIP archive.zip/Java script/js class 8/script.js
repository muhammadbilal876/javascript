function toastifyError(msg){
Toastify({
    text: msg,
    duration: 3000,
    destination: "https://github.com/apvarun/toastify-js",
    newWindow: true,
    close: true,
    gravity: "bottom", // `top` or `bottom`
    position: "left", // `left`, `center` or `right`
    stopOnFocus: true, // Prevents dismissing of toast on hover
    style: {
      background: "linear-gradient(to right, #93291e, #ed213a)",
    },
    onClick: function(){} // Callback after click
  }).showToast();

}

function ifElse(){
    let now  = new Date();
    let toDay = now.getDay();

    if(toDay === 0){
        toastifyError("It's Sunday")
    }
    else if(toDay === 1){
        toastifyError("It's Monday")
    }
    else if(toDay === 2){
        toastifyError("It's Tuesday")
    } else {
        toastifyError("It's some other day")
    }
}
function Switch(){
    let now = new Date();
    let toDay = now.getDay();

    switch(toDay){
        case 0:
            toastifyError("It's Sunday")
            break;
        case 1:
            toastifyError("It's Monday")
            break;
        case 2:
            toastifyError("It's Tuesday")
            break;
        default:
            toastifyError("It's some other day")
    }
}
// function askingTheName(){
//     let name;
    

//     do {
//         name = prompt('Enter your name')

//         console.log(name)

//     } while (name === null || name === "" || name.length < 3);

// }

function askingTheName(){
   let name;

   do{
    name =prompt('Enter your name')

   } while (name === null || name === "" || name.length < 3);

   document.getElementById("box").innerHTML = name
}