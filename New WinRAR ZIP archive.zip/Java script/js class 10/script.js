// const users = []
// const getInputFieldValue = id => document.getElementById(id).value
// const getRandomId = () => Math.random().toString(36).slice(2)

// cons handleRegister = () => {
//     event.preventDefault();

//     let fullName = getInputFieldValue("fullName")
//     let email = getInputFieldValue("email")
//     let password = getInputFieldValue("password")

//     fullName = fullName.trim()

//     if (fullName.length < 3) {return alert("Please enter your full name")}
//     if (password.length < 8) {return alert("Password must be atlease 8 chracs.")}

//     const user = {
//         fullName: fullName,
//         email: email,
//         password: password,
//         id: getRandomId(),
//         roleNumber: user.length + 1,
//         status: "active",
//         isFeePaid: false
//     }
//     user.push(user)
// }

// let user = {
//     firstName: "Muhammad",
//     lastname: "Bilal",
//     fullName: function(){
        
//     }
// }








// function showOutput(Output){
//     document.getElementById("Output").innerHTML = Output
// }
// function clearOutput() {
//     document.getElementById("Output").innerHTML = "";
// }

// function getFieldValue(fieldid){
//   return  document.getElementById(fieldid).value;
// }

// function getRandomId(){
//     return Math.random().toString(36).slice(2)
// }

// let emailFormat = /^([a-zA-z0-9_\.\-])+\@(([a-zA-z0-9\-])+\.)+([a-zA-z0-9]{2,4})+$/;


// // .................................................................................
// let users = []

// function User(firstName, lastname, email, dob) {
//     this.firstName = firstName;
//     this.lastname = lastname;
//     this.email = email;
//     this.dob = dob;
//     this.calculatAge();
//         // let dob = new Date(this.dob)
//         let currentDate = new Date()
    
     
//         //calculate month difference from current date in time  
//         let month_diff = currentDate.getTime() - dob.getTime();  
          
//         //convert the calculated difference in date format  
//         let age_dt = new Date(month_diff);   
          
//         //extract year from date      
//         let year = age_dt.getFullYear();  
          
//         //now calculate the age of the user  
//         let age = Math.abs(year - 1970);  
        
//         return age 
    
// }

// // Reference of this function https://www.javatpoint.com/calculate-age-using-javascript
// User.prototype.calculatAge = function () {

//     let dob = new Date(this.dob)
//     let currentDate = new Date()

 
//     //calculate month difference from current date in time  
//     let month_diff = currentDate.getTime() - dob.getTime();  
      
//     //convert the calculated difference in date format  
//     let age_dt = new Date(month_diff);   
      
//     //extract year from date      
//     let year = age_dt.getFullYear();  
      
//     //now calculate the age of the user  
//     let age = Math.abs(year - 1970);  
    
//     return age 
// }

// function handleSubmit() {
//     event.preventDefault();

//     let firstName = getFieldValue("firstName")
//     let lastName = getFieldValue("lastName")
//     let email = getFieldValue("email")
//     let dob = getFieldValue("dob")

//     // firstName = firstName.trime();
//     // lastName = lastName.trime();
//     // email = email.trime()

//     if(firstName.length < 3){
//         alert("Please enter your first name correctly.", "error")
//         return
//     }
//     if(!emailFormat.test(email)){
//         alert("Please enter your email correctly.", "error")
//         return
//     }
//     if(!dob){
//         alert("Please enter your date of birth.", "error")
//         return
//     }


// let user = {firstName, lastName, email, dob}

// user.id = getRandomId()
// user.dateCreated = new Date().getTime()
//  user.status = "active"
//  user.role = "student"

// users.push(user)

// // if (user.length < 5){
// //     user.push(users)
// // } else{
// //     showNotification("Limit full", "error")
// //     return
// //     showNotification()
// // }

// showNotification("A new user has been successfully added.", "success")
// showTable()
// }

// function showTable(){
//     if(!users.length){
//         showNotification("There is not a single user available", "error")
//         return
//     }

//     let tableStartingCode = '<div class="table-responsive"><table class="table">'
//     let tableHead = '<thead><tr><th scop="col">#</th><th scop="col">First Name</th><th scop="col">Last Name</th><th scop="col">Email</th><th scop="col">Date of Birth</th><th scop="col">Age</th></tr></thead>'

//     let tableEndingCode = '</table></div>'

//     let tableBody = ''

//     for(let i = 0; i < users.length; i++){
//         tableBody += '<tr><th scop="row">'+ (i + 1) + '</th><td>' + users[i].firstName + '</td><td>' +users[i].lastName + '</td><td>' + users[i].email + '</td><td>' + users[i].dob + '</td><td>' + users[i].calculatAge() + '</td></tr>'
//     }

//     let table = tableStartingCode + tableHead + "<tbody>" + tableBody + "</tbody>" + tableEndingCode

//     // showTable()
//     // console.log(table)

// }

function printUser(){
    if(!users.length){
        alert("There is not a single user available", "error")
        return
    }
    // for(let i = 0; i < users.length; i++){
    //     let user = users[i]
    //     console.log(user)
    // }   
    console.log(users)
}

function showNotification(msg, type){

    let bgColor;

    switch (type) {
        case "success":
            bgColor = "linear-gradient(to right, #1D976C, #93F9B9)"
            break;
            case "error":
            bgColor = "linear-gradient(to right, #93291e, #ed213a)"
            break;
        default:
            bgColor = "#000"
            break;
    }


    Toastify({
        text: msg,
        duration: 3000,
        destination: "https://github.com/apvarun/toastify-js",
        newWindow: true,
        close: true,
        gravity: "bottom", // `top` or `bottom`
        position: "left", // `left`, `center` or `right`
        stopOnFocus: true, // Prevents dismissing of toast on hover
        style: {
          background: bgColor,
        },
        onClick: function(){} // Callback after click
      }).showToast();
    
    
}
















function showOutput(output) {
    document.getElementById("output").innerHTML = output;
}

function clearOutput() {
    document.getElementById("output").innerHTML = "";
}

function getFieldValue(fieldId) {
    return document.getElementById(fieldId).value;
}

function getRandomId() {
    return Math.random().toString(36).slice(2);
}

let emailFormat = /^([a-zA-z0-9_\.\-])+@(([a-zA-z0-9\-])+\.)+([a-zA-z0-9]{2,4})+$/;

let users = [];

function User(firstName, lastName, email, dob) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.dob = dob;
    this.age = this.calculateAge(); // Save age directly
}

User.prototype.calculateAge = function () {
    let dob = new Date(this.dob);
    let currentDate = new Date();
    let month_diff = currentDate.getTime() - dob.getTime();
    let age_dt = new Date(month_diff);
    let year = age_dt.getFullYear();
    let age = Math.abs(year - 1970);
    return age;
};

function handleSubmit(event) {
    event.preventDefault();

    let firstName = getFieldValue("firstName");
    let lastName = getFieldValue("lastName");
    let email = getFieldValue("email");
    let dob = getFieldValue("dob");

    if (firstName.trim().length < 3) {
        alert("Please enter your first name correctly.");
        return;
    }
    if (!emailFormat.test(email)) {
        alert("Please enter your email correctly.");
        return;
    }
    if (!dob) {
        alert("Please enter your date of birth.");
        return;
    }

    let user = new User(firstName, lastName, email, dob);
    user.id = getRandomId();
    user.dateCreated = new Date().getTime();
    user.status = "active";
    user.role = "student";

    users.push(user);

    showNotification("A new user has been successfully added.", "success");
    showTable();
}

function showNotification(message, type) {
    // Assuming you have a function to show notifications
    console.log(type + ": " + message);
}

function showTable() {
    if (!users.length) {
        showNotification("There is not a single user available", "error");
        return;
    }

    let tableStartingCode = '<div class="table-responsive"><table class="table">';
    let tableHead = '<thead><tr><th scope="col">#</th><th scope="col">First Name</th><th scope="col">Last Name</th><th scope="col">Email</th><th scope="col">Date of Birth</th><th scope="col">Age</th></tr></thead>';
    let tableEndingCode = '</table></div>';

    let tableBody = '';

    for (let i = 0; i < users.length; i++) {
        tableBody += '<tr><th scope="row">' + (i + 1) + '</th><td>' + users[i].firstName + '</td><td>' + users[i].lastName + '</td><td>' + users[i].email + '</td><td>' + users[i].dob + '</td><td>' + users[i].calculateAge() + '</td></tr>';
    }

    let table = tableStartingCode + tableHead + "<tbody>" + tableBody + "</tbody>" + tableEndingCode;

    showOutput(table);
}
