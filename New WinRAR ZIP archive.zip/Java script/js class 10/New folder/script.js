document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    let email = document.getElementById('loginEmail').value;
    let password = document.getElementById('loginPassword').value;

    // This is just a simple example, you would normally check these details against your backend
    if (email === "test@example.com" && password === "password123") {
        alert('Login successful!');
    } else {
        alert('Invalid email or password!');
    }
});

