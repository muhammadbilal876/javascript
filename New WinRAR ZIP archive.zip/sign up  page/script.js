// let signUpBtn = document.querySelector('.signupBtn')
// let signInBtn = document.querySelector('.signInBtn')
// let nameField = document.querySelector('.nameField')
// let title = document.querySelector('.title')
// let underline = document.querySelector('.underline')
// let text = document.querySelector('.text')
// signInBtn.addEventListener('click',()=>{
//     nameField.style.maxHeight = '0';
//     title.innerHTML = 'Sign In';
//     text.innerHTML = 'Lost Password';
//     signUpBtn.classList.add('disable');
//     signInBtn.classList.remove('disable');
//     underline.style.transform = 'translateX(35px)'
// })

// signUpBtn.addEventListener('click',()=>{
//     nameField.style.maxHeight = '60px';
//     title.innerHTML = 'Sign Up';
//     text.innerHTML = 'Password Suggestions';
//     signUpBtn.classList.remove('disable');
//     signInBtn.classList.add('disable');
//     underline.style.transform = 'translateX(0px)'
// })


// let users = [];

//         function signUp() {
//             let name = document.getElementById('nameField').value;
//             let email = document.getElementById('email').value;
//             let password = document.getElementById('password').value;

//             if (!name || !email || !password) {
//                 alert('Please fill all fields.');
//                 return;
//             } else{

//             users.push({email: email, password: password });
//         }
//                 alert('User signup successful!');
                
//     document.getElementById("nameField").value = "";
//     document.getElementById("email").value = "";
//     document.getElementById("password").value = "";
//     return
//         }

//         function signIn() {
//             let email = document.getElementById('email').value;
//             let password = document.getElementById('password').value;

//             let user = users.find(user => user.email === email);

//             if (!user || user.password !== password) {
//                 alert('Invalid username or password!');
//                 return;
//             }

//             alert('User login successful!');
//             return
//         }
















let signUpBtn = document.querySelector('.signupBtn');
let signInBtn = document.querySelector('.signInBtn');
let nameField = document.querySelector('.nameField');
let title = document.querySelector('.title');
let underline = document.querySelector('.underline');
let text = document.querySelector('.text');

signInBtn.addEventListener('click', () => {
    nameField.style.maxHeight = '0';
    title.innerHTML = 'Sign In';
    text.innerHTML = 'Lost Password';
    signUpBtn.classList.add('disable');
    signInBtn.classList.remove('disable');
    underline.style.transform = 'translateX(35px)';
});

signUpBtn.addEventListener('click', () => {
    nameField.style.maxHeight = '60px';
    title.innerHTML = 'Sign Up';
    text.innerHTML = 'Password Suggestions';
    signUpBtn.classList.remove('disable');
    signInBtn.classList.add('disable');
    underline.style.transform = 'translateX(0px)';
});

let users = [];

let emailFormat = /^([a-zA-z0-9_\.\-])+\@(([a-zA-z0-9\-])+\.)+([a-zA-z0-9]{2,4})+$/;

function signUp() {
    let name = document.getElementById('nameField').value;
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;

    if (!name || name.length < 3) {
        alert('Please fill all fields.');
        return;
    }
    if (!email || name.length < 3) {
        alert('Please fill all fields.');
        return;
    }

    users.push({ email: email, password: password });
    alert('User signup successful!');

    document.getElementById("nameField").value = "";
    document.getElementById("email").value = "";
    document.getElementById("password").value = "";
}

function signIn() {
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;

    if (!email || !password) {
        alert('Please fill all fields.');
        return;
    }

    let user = users.find(user => user.email === email);

    if (!user || user.password !== password) {
        alert('Invalid username or password!');
        return;
    }

    alert('User login successful!');
}
